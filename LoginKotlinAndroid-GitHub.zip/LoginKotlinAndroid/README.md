# LoginKotlinAndroid

Login simple creado con Kotlin + Jetpack Compose para Android Studio.

## Características
- Campo de usuario/correo.
- Campo de contraseña.
- Botón Iniciar sesión.
- Validación básica.
- Mensajes de error.
- Pantalla de bienvenida al iniciar sesión.

## Credenciales de prueba
- Usuario: `admin`
- Contraseña: `123456`

## Abrir en Android Studio
1. Descarga o clona este repositorio.
2. Abre la carpeta `LoginKotlinAndroid` en Android Studio.
3. Espera a que Gradle sincronice el proyecto.
4. Ejecuta la aplicación en un emulador o dispositivo Android.

## Subir a GitHub
```bash
git init
git add .
git commit -m "Login simple en Kotlin"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/LoginKotlinAndroid.git
git push -u origin main
```

> Este proyecto es educativo: las credenciales están escritas en el código y no debe usarse así en una aplicación real.
